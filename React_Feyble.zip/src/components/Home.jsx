import { FaUser } from "react-icons/fa6";


function Home() {
  return (
    <div>
      <h1 data-aos="fade-left" data-aos-duration="3000">Home pg <FaUser />
      </h1>
    </div>
  );
}

export default Home;