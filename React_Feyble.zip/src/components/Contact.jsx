import React from 'react'
import { FaUser } from "react-icons/fa6";

const Contact = () => {
  return (
    <>
      <h1 data-aos="fade-left" data-aos-duration="3000">Contact pg <FaUser />
      </h1>
    </>
  )
}

export default Contact